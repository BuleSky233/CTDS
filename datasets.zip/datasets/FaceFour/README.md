# FaceFour

Data are outlines of face. 

Train size: 24

Test size: 88

Missing value: No

Number of classses: 4

Time series length: 350

Data donated by Ann Ratanamahatana and Eamonn Keogh (see [1]).

[1] http://www.timeseriesclassification.com/description.php?Dataset=FaceFour
